let txt = {
    film1: [{
            "filmcím": "Avatar",
            "műfaj": "Sci-fi",
            "megjelenéséve": "2009"
            "kép:kepek/avatar.jpg"
        },


    ],
    film2: [
        { "filmcím": "Aquaman", "műfaj": "Sci-fi", "megjelenéséve": "2018", "kep:kepek/avatar.jpg" },

    ],
    film3: [

        { "filmcím": "Szupercella", "műfaj": "Sci-fi", "megjelenéséve": "2012", "kép:kepek/avatar.jpg" },
    ],
    film4: [

        { "filmcím": "Star Wars", "műfaj": "Sci-Fi", "megjelenéséve": "2017", "kép:kepek/avatar.jpg" }
    ]
}
$(function() {
    let fajlnev = "filmek.json"
    jsonbeolvasas(fajlnev, tablazat, film1, film2, film3, film4)
})

function beolvasas(fajlnev, callback, tomb, kulcs) {
    fetch(fajlnev)
        .then((res) => res.json())
        .then((data) => {
            tomb = data[kulcs]
            callback(tomb)
        })
}

function tablazat(txt) {
    console.log(txt)
    $("article").append("<table>")

    let txt =
        "<tr><th>Filmcím</th><th>műfaj</th><th>MegjelenésÉve</th></tr>"

    for (let i = 0; i < tomb.length; i++) {
        txt += "<tr><td class='kep'>" + txt[i].filmcím + "</td><td>" + txt[i].műfaj + "</td><td>" + txt[i].megjelenéséve + "</td><td><img src=" + txt[i].kép + "></td></tr>"
    }
    $("article table").append(txt)
    kep(txt)
}

function kep(txt) {
    $(".kep").click(function() {
        for (let i = 0; i < txt.length; i++) {
            if ($(this).html() == txt[i].filmcím) {
                $("div").html("<img class='kepek'>")
                $("article div img").attr("src", txt[i].kép)
            }
        }
    })
}